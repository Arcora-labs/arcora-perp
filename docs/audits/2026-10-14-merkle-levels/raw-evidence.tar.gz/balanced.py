import hashlib,json,statistics,sys
from pathlib import Path
root=Path.cwd();work=root/'target/merkle-levels-20261014';out=work/'balanced';out.mkdir(exist_ok=False)
sys.path.insert(0,str(root/'scripts/local-verification'));import finite_preparation_profile as p
source=p.source_identity();assert source==json.loads((work/'current/source.json').read_text())
binaries={'baseline':work/'baseline-gateway','current':work/'recovered-release-gateway'}
expected={'baseline':json.loads((work/'baseline/binary.json').read_text())['sha256'],'current':json.loads((work/'recovered/binary.json').read_text())['sha256']}
assert all(p.sha(binary.read_bytes())==expected[n] for n,binary in binaries.items())
allrows=[];commands=[]
for block in range(4):
 for implementation in (['baseline','current'] if block%2==0 else ['current','baseline']):
  name=f'{block}-{implementation}'
  record,text=p.capture(out,name,[str(binaries[implementation]),p.PREFIX+'observation::finite_preparation_cpu','--exact','--ignored','--nocapture','--test-threads=1'])
  p.check_test_result(text,1);rows=p.records(text,'FINITE_CPU_SAMPLE ');p.validate_cpu(rows)
  commands.append({'block':block,'implementation':implementation,**record})
  allrows.extend({'block':block,'implementation':implementation,**row} for row in rows)
  print(name,'PASS',len(rows),'samples',flush=True)
assert len(allrows)==960
summary={}
for fixture in p.CASES:
 summary[fixture]={}
 for phase in p.PHASES:
  v={}
  for implementation in binaries:
   values=[r['thread_cpu_ns']/r['repetitions']/1000 for r in allrows if r['fixture']==fixture and r['phase']==phase and r['implementation']==implementation]
   assert len(values)==20
   v[implementation]={'median_us':statistics.median(values),'min_us':min(values),'max_us':max(values),'batch_samples':20,'calls_per_batch':10}
  v['observed_median_reduction_percent']=100*(1-v['current']['median_us']/v['baseline']['median_us'])
  summary[fixture][phase]=v
assert p.source_identity()==source and all(p.sha(binary.read_bytes())==expected[n] for n,binary in binaries.items())
result={'schema':'arcora-merkle-levels-balanced-release/v1','source_sha256':source['measurement_source_sha256'],'binary_sha256':expected,'blocks':4,'actual_cpu_tests':{'passed':8,'failed':0,'ignored':0},'raw_sample_count':960,'summary':summary,'raw_samples':allrows,'commands':commands,'limits':['Separate executable processes, AB/BA order across four blocks; no fixed CPU affinity/frequency','Medians of twenty ten-call batch averages per fixture/phase/implementation, not user-level p95/p99','Proof responses synthetic; phases overlap and cannot be added','Original current build supervisor timed out; recovered executable verified separately; no build-success claim']}
p.dump(work/'balanced-summary.json',result)
for fixture,phases in summary.items():
 for phase in ['claim_paths','native_replay_owned','prepare_unproved_total','clocked_prepare_cached_stub_total']:
  r=phases[phase];print(fixture,phase,round(r['baseline']['median_us'],3),'->',round(r['current']['median_us'],3),round(r['observed_median_reduction_percent'],2),'%',flush=True)
