import hashlib,json,sys
from pathlib import Path
root=Path.cwd();work=root/'target/merkle-levels-20261014';out=work/'recovered';out.mkdir(exist_ok=False)
sys.path.insert(0,str(root/'scripts/local-verification'))
import finite_preparation_profile as p
source=p.source_identity();old=json.loads((work/'current/source.json').read_text());assert source==old
p.dump(out/'source.json',source)
provenance=json.loads((work/'recovered-binary-provenance.json').read_text());p.dump(out/'provenance.json',provenance)
binary=str(work/'recovered-release-gateway');binary_sha=p.sha(Path(binary).read_bytes());assert binary_sha==provenance['binary_sha256']
p.dump(out/'binary.json',{'path':binary,'sha256':binary_sha})
_,text=p.capture(out,'correctness',[binary,p.PREFIX,'--skip','rss_','--skip','observation::','--nocapture','--test-threads=1'])
p.check_test_result(text,4)
metadata=p.records(text,'FINITE_FIXTURE ');assert len(metadata)==3
metadata={m['fixture']:p.validate_metadata(m) for m in metadata};assert set(metadata)==set(p.CASES)
_,text=p.capture(out,'cpu',[binary,p.PREFIX+'observation::finite_preparation_cpu','--exact','--ignored','--nocapture','--test-threads=1'])
p.check_test_result(text,1);rows=p.records(text,'FINITE_CPU_SAMPLE ');cpu=p.validate_cpu(rows)
rss={}
for name,(_,_,test) in p.CASES.items():
 rec,text=p.capture(out,name,[binary,p.PREFIX+test,'--exact','--ignored','--nocapture','--test-threads=1'])
 p.check_test_result(text,1);m=p.records(text,'FINITE_RSS_FIXTURE ');assert len(m)==1 and p.validate_metadata(m[0])==metadata[name]
 assert rec['wait4_ru_maxrss_raw']>0
 rss[name]={'pid':rec['pid'],'peak_rss_bytes':rec['wait4_ru_maxrss_raw'],'peak_rss_mib':rec['wait4_ru_maxrss_raw']/1048576,'samples':1}
assert len({v['pid'] for v in rss.values()})==3
assert p.source_identity()==source and p.sha(Path(binary).read_bytes())==binary_sha
baseline=json.loads((work/'baseline/summary.json').read_text());assert metadata==baseline['fixtures']
summary={'schema':'arcora-finite-preparation-profile/recovered-executable-v1','status':'PASS for executed tests only; build supervisor timed out','measurement_source_sha256':source['measurement_source_sha256'],'binary_sha256':binary_sha,'actual_tests':{'correctness_passed':4,'cpu_passed':1,'rss_passed':3,'failed':0,'ignored':0},'cpu_samples':len(rows),'fixtures':metadata,'cpu':cpu,'rss':rss,'provenance':provenance,'limits':baseline['limits']}
p.dump(out/'summary.json',summary)
comparison={'baseline_source':baseline['measurement_source_sha256'],'current_source':source['measurement_source_sha256'],'fixture_metadata_exact':True,'phases':{},'rss':{'baseline':baseline['rss'],'current':rss},'limits':summary['limits'],'current_build_supervisor_timed_out':True}
for name in p.CASES:
 comparison['phases'][name]={}
 for phase in p.PHASES:
  a=baseline['cpu'][name][phase]['thread_cpu_us_per_operation'];b=cpu[name][phase]['thread_cpu_us_per_operation']
  comparison['phases'][name][phase]={'baseline_us':a,'current_us':b,'median_reduction_percent':100*(1-b['median']/a['median'])}
p.dump(work/'comparison.json',comparison)
print('RECOVERED_TESTS_COMPLETE',json.dumps(summary['actual_tests']),flush=True)
for name,phases in comparison['phases'].items():
 for phase in ['claim_paths','prepare_unproved_total','clocked_prepare_cached_stub_total']:
  r=phases[phase];print(name,phase,r['baseline_us']['median'],'->',r['current_us']['median'],'us',round(r['median_reduction_percent'],2),'%',flush=True)
